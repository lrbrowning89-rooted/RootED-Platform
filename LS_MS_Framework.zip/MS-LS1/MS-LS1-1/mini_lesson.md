# Mini-Lesson Blueprint

Outline for remediation mini-lesson.