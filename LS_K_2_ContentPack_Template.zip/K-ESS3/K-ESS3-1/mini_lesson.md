# Mini-Lesson Blueprint

(Short remediation lesson outline.)